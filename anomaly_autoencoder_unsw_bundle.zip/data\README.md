Place UNSW-NB15 files here (not committed).

Expected filenames if you download/extract the official CSVs:
- UNSW_NB15_training-set.csv
- UNSW_NB15_testing-set.csv

Note: in this workspace these files were copied here from `transformer_tabular/archive/` for convenience.

You can also keep them elsewhere and pass `--data_dir` or `--zip_path` to the scripts.
